# Stage 3 Review Packet — Theme Synthesis Worksheet

Protocol (two-researcher consensus, Theme and Topic system):
1. PRIMARY researcher: for each topic, read the sampled documents,
   confirm the modal LLM label is relevant to the sample, and note
   overlapping thematic connections between topics — reading against
   the current literature of the target domain.
2. Group topics by conceptual similarity into candidate themes.
3. SENIOR researcher: independently review and critique; reach
   consensus through discussion.
4. Record the consensus in theme_map_TEMPLATE.csv (save as
   theme_map.csv) and set `themes` in config.py accordingly.

A fragmented vote (low modal share) flags a semantically ambiguous
topic — give it extra scrutiny here.

## Topic 0: "Cozy Home Tasting Experience"
- Modal vote share: 60.0% (12/20); margin over runner-up: 50.0%
- Representative words: cheer, taste, room, small, slow, back, say, record, complete, sip
- Sampled documents (n=15):
    - Taste test complete. Say hello to the Watermelon Mint variety pack, landing on shelves this month. As always, cheers.
    - Just saying. Peak fall colors in Charlotte calls for an Old Ferry IPA. As always, cheers.
    - Quick reminder: Anniversary dinners, good records and Coral Cove. Pour accordingly.
    - Quick reminder: Snow days, the last light of the day and a can of Tidepool. Enjoy responsibly.
    - Small joys. Wedding toasts, a good playlist and a Coral Cove and pineapple.
    - Just saying. A foggy morning and a Kingsgate pale ale on the porch. Raise a glass.
    - Straight from the tasting room. Spring forward, sip slowly. As always, cheers.
    - Just saying. Porch swings, a well-worn armchair and Hollowmere.
    - Noted. Fishing weekends, a crackling fire and Brightwater. Raise a glass.
    - Quick reminder: Wedding toasts, string lights and Mareta Rum. #MaretaMoments #Cheers
    - An Old Ferry IPA with tacos. Trust us. 21+ only, please.
    - Small joys. A fresh keg pours a deep amber color.
    - Quick reminder: Introducing Lanternlight Lager Peach Tea, bright and crisp with a clean finish. As always, cheers.
    - Taste test complete. Road trips, an open window and a Kingsgate pint. Sip slow.
    - Limited release: Black Cherry is back for a few short weeks. #CopperCheers #Cheers

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 1: "Sports-Themed Alcohol Promotions During COVID-19"
- Modal vote share: 35.0% (7/20); margin over runner-up: 5.0%
- Representative words: game, playoff, season, day, team, opening, gameday, kickoff, ready, root
- Sampled documents (n=15):
    - Third quarter, tied game, an Old Ferry lager in hand. #GameDay
    - What a finish! Grab a Kingsgate pale ale and settle in for the big game. #GameDay
    - Tip-off at 9pm ET. Hollowmere is ready when you are. Go team.
    - What a finish! Fantasy draft night with the league: snacks, smack talk and Lanternlight. Who are you rooting for?
    - Proud to support designated driver programs in Chicago this holiday season. #BrightwaterLife
    - Proud to be the official beer of the Boston football club this season. Drink responsibly.
    - What a finish! Race day in Denver, and the Brightwater is on ice. #Playoffs
    - Opening day vibes. Third quarter, tied game, Hollowmere in hand. Who are you rooting for?
    - Opening day vibes. Hockey night in Milwaukee: puck drops at 9pm EST. Go team.
    - Nothing beats a can of Brightwater at the ballpark on opening day. Who are you rooting for?
    - It's playoff season. Fantasy draft night with the league: snacks, smack talk and an Old Ferry lager. #GameDay
    - Win or lose, an Old Ferry IPA tastes better with your team.
    - The Austin marathon runs tonight. Cheering on every runner, and saving them a Lanternlight for later. Go team.
    - Tailgate ready? Soccer season opener in Austin this weekend. Bring your scarf and your team spirit. Drink responsibly.
    - Brackets are busted and a Coral Cove and pineapple is cold. Who's still alive?

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 2: "Pandemic Alcohol Delivery Services"
- Modal vote share: 50.0% (10/20); margin over runner-up: 30.0%
- Representative words: pourly, delivery, order, deliver, code, door, first, doorstep, doorstepdrinks, delivereddaily
- Sampled documents (n=15):
    - Your couch, your rules. Have a Lanternlight delivered straight to your door. Use code SIPHOME for $5 off your first order. #DoorstepDrinks
    - Lanternlight Lager is now available for same-day delivery in San Diego through Pourly.
    - Skip the store. Contactless delivery of Coral Cove Rum, from our shelf to your doorstep.
    - Happy hour, delivered. Free delivery on your first Pourly order of an Old Ferry lager. Code STAYIN5. #DeliveredDaily
    - No pants required. Have a Coral Cove and pineapple delivered straight to your door. Use code HOMEBAR for $5 off your first order.
    - No pants required. Order a Kingsgate pint on Pourly and get $5 off your first delivery with code HOMEBAR.
    - Restock without leaving the house. Get a Prairie Crown delivered to your door in 60 minutes or less with Pourly. Cheers from a safe distance.
    - Happy hour, delivered. Coral Cove Rum is now available for same-day delivery in Detroit through Pourly. #DoorstepDrinks
    - Your couch, your rules. Hollowmere Herbal Liqueur is now available for same-day delivery in Omaha through Pourly. #DeliveredDaily
    - Restock without leaving the house. Brightwater Hard Seltzer is now available for same-day delivery in Boston through Pourly. Must be 21+ to order.
    - Running low? Get a Coral Cove and pineapple delivered to your door in 60 minutes or less with Pourly.
    - Running low? Delivery is on us this weekend: order Kingsgate through Pourly with code CHEERS5.
    - Contactless delivery of Lanternlight, from our shelf to your doorstep. Must be 21+ to order.
    - Your couch, your rules. Order a Kingsgate pint on Pourly and get $5 off your first delivery with code FIRSTROUND.
    - Doorstep delivery is the new last call. Have an ice-cold Lanternlight delivered straight to your door. Use code SIPHOME for $5 off your first order. #DeliveredDaily

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 3: "Social Media Contest Promotions"
- Modal vote share: 20.0% (4/20); margin over runner-up: 0.0%
- Representative words: win, chance, giveaway, follow, enter, winner, photo, howdyneighbor, post, caption
- Sampled documents (n=15):
    - Giveaway alert. Enter our fall sweepstakes for a chance at concert tickets in Chicago.
    - Follow us for more. Follow us on Instagram for exclusive giveaways and first looks at new releases. Good luck!
    - Last chance to enter. We're giving away ten Coral Cove Rum hoodies. Follow and retweet to enter. Good luck!
    - Follow us for more. Retweet this post for a chance to win Prairie Crown Lager glassware for your home bar. #Giveaway
    - New merch alert. Say #HowdyNeighbor to a friend below. Five winners get a #HowdyNeighbor hoodie. Winners announced Friday.
    - Want to win? Enter our fall sweepstakes for a chance at concert tickets in Milwaukee. Rules in bio. 21+.
    - Tag your crew. Say #HowdyNeighbor to a friend below. Five winners get a #HowdyNeighbor hoodie. Winners announced Friday. @PrairieCrown
    - Win it before it's gone. Show us your best happy hour selfie for a chance to win merch for your video call crew. @PrairieCrown
    - Comment below. Enter our fall sweepstakes for a chance at concert tickets in Detroit. Rules in bio. 21+.
    - It's giveaway week. Follow us on Instagram for exclusive giveaways and first looks at new releases.
    - Giveaway time! Show us your best happy hour selfie for a chance to win merch for your video call crew. Winners announced Friday.
    - Who would you share one with right now? Say #HowdyNeighbor to a friend below. Five winners get a #HowdyNeighbor hoodie. Winners announced Friday.
    - It's giveaway week. Retweet this post for a chance to win Lanternlight Lager glassware for your home bar. Good luck!
    - Last chance to enter. Like, follow and tag two friends to enter our summer giveaway. Rules in bio. 21+.
    - Contest time! Enter our fall sweepstakes for a chance at concert tickets in Detroit.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 4: "Homebound Happy Hour"
- Modal vote share: 55.0% (11/20); margin over runner-up: 45.0%
- Representative words: stay, home, drinking, fridge, homebarhours, couch, mug, stayhomesips, else, dress
- Sampled documents (n=15):
    - Hot take: staying home is easier with Lanternlight and a video call with the crew. #VirtualHappyHour @LanternlightBeer
    - Drinking at home hits different when a Hollowmere shot is cold and the couch is warm. Stay home, stay safe.
    - Isolation update: your living room is the best bar in town tonight. Stay home with a can of Brightwater. #HomeBarHours @BrightwaterSeltzer
    - Virtual happy hour starts at 5, and a cold Prairie Crown is already on my desk. Stay home, stay safe.
    - Hot take: make it a quarantini night with Kingsgate and whatever is left in the fridge. Stay home, stay safe.
    - WFH hack: virtual happy hour starts at 5, and a Kingsgate pale ale is already on my desk. Who else is drinking from a mug today?
    - Make it a quarantini night with Brightwater and whatever is left in the fridge. #HomeBarHours
    - Pro tip: Lanternlight pairs perfectly with a blanket, a movie and nowhere to be. Stay home, stay safe.
    - Staying home is easier with an Old Ferry IPA and a video call with the crew. Who else is drinking from a mug today?
    - Isolation update: the home bar is open, the dress code is pajamas, and a Lanternlight is pouring. #HomeBarHours @LanternlightBeer
    - Drinking at home hits different when Coral Cove Rum is cold and the couch is warm.
    - WFH hack: Brightwater pairs perfectly with a blanket, a movie and nowhere to be. Who else is drinking from a mug today?
    - The commute is now from the couch to the fridge for Hollowmere. Who else is drinking from a mug today?
    - The commute is now from the couch to the fridge for a Kingsgate pale ale. #StayHomeSips
    - Day 23 of staying home. Staying home is easier with Lanternlight and a video call with the crew. #HomeBarHours

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 5: "Virtual Home Concerts"
- Modal vote share: 75.0% (15/20); margin over runner-up: 65.0%
- Representative words: instagram, live, livingroomtour, set, tonight, facebook, edition, stream, kitchen, tune
- Sampled documents (n=15):
    - Your living room, our stage. Tonight's #LivingRoomTour stop: Maya Nakamura live from their kitchen at 8pm CT on Instagram. Set your reminder.
    - The #LivingRoomTour: Home Edition streams on Instagram and Facebook Live Thursday at 8pm CT. Set your reminder.
    - We're live in five. Join the #LivingRoomTour on Instagram Live Thursday at 7pm CT with a set from Mateo Ashby.
    - We're live in five. Tonight's #LivingRoomTour stop: Marcus Duval live from their kitchen at 8pm ET on Instagram. See you there.
    - Going live now! The #LivingRoomTour: Home Edition streams on Instagram and Facebook Live tonight at 8pm ET. Set your reminder.
    - Your living room, our stage. Tonight's #LivingRoomTour stop: Marcus Lindqvist live from their kitchen at 6pm PT on Instagram. Set your reminder.
    - Don't miss it. Tonight's #LivingRoomTour stop: Sofia Lindqvist live from their kitchen at 8pm ET on Instagram. Link in bio.
    - Your living room, our stage. The #LivingRoomTour: Home Edition streams on Instagram and Facebook Live tonight at 7pm ET. @KingsgateBrew
    - Don't miss it. Join the #LivingRoomTour on Instagram Live tomorrow night at 7pm ET with a set from Darius Whitfield. Set your reminder. @LanternlightBeer
    - The #LivingRoomTour: Home Edition streams on Instagram and Facebook Live this weekend at 6pm PT. Set your reminder.
    - Your living room, our stage. Tonight's #LivingRoomTour stop: Marcus Fontaine live from their kitchen at 8pm ET on Instagram. Set your reminder. @KingsgateBrew
    - Your living room, our stage. Darius Nakamura is going live on our Instagram at 6pm PT for the #LivingRoomTour. Grab a Kingsgate pale ale and tune in. Link in bio.
    - Your living room, our stage. The #LivingRoomTour: Home Edition streams on Instagram and Facebook Live tomorrow night at 8pm CT.
    - The #LivingRoomTour: Home Edition streams on Instagram and Facebook Live tonight at 9pm ET. @LanternlightBeer
    - Going live now! Join the #LivingRoomTour on Instagram Live Thursday at 6pm EST with a set from Darius Brooks.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 6: "Alcohol E-Commerce and Delivery Services During COVID-19"
- Modal vote share: 40.0% (8/20); margin over runner-up: 20.0%
- Representative words: online, order, ship, gift, shop, delivers, minute, door, shipping, store
- Sampled documents (n=15):
    - Last-minute gift? Covered. Prairie Crown Lager gift packs ship to your door. Order online today.
    - Lanternlight Lager gift packs ship to your door. Order online today. Link in bio.
    - Our online shop now delivers Kingsgate in Omaha.
    - Can't make it to the store? Order a Copper Hollow old fashioned online for curbside pickup at your local store. Link in bio.
    - Shopping for the bottle lover in your life? Coral Cove Rum gift packs ship to your door. Order online today. Must be 21+ to order.
    - Last-minute gift? Covered. Our online shop now delivers a can of Brightwater in Omaha.
    - Can't make it to the store? Ship a bottle of Lanternlight Lager anywhere it's legal, ordered online in minutes.
    - Shopping for the bottle lover in your life? Ship a bottle of Old Ferry Brewing anywhere it's legal, ordered online in minutes. Must be 21+ to order.
    - Stock the bar before the big game. Order Hollowmere online and have it shipped to their door. #ShopOnline
    - Gift giving made easy. Order a Copper Hollow neat online and have it shipped to their door. Must be 21+ to order.
    - Last-minute gift? Covered. Order Coral Cove Rum online for curbside pickup at your local store.
    - Order Old Ferry online and have it shipped to their door. Free shipping this week.
    - Stock the bar before the big game. Order online and get Old Ferry delivered before the weekend. Must be 21+ to order.
    - Our online shop now delivers a can of Brightwater in Kansas City. #ShopOnline
    - Hollowmere Herbal Liqueur gift packs ship to your door. Order online today. Must be 21+ to order.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 7: "Hospitality Industry Support During COVID-19"
- Modal vote share: 25.0% (5/20); margin over runner-up: 10.0%
- Representative words: restaurant, worker, fund, help, donate, support, servethemstrong, bartender, takeout, local
- Sampled documents (n=15):
    - Restaurant spotlight: Visit our partner restaurants in Charlotte this week; a dollar from every a cold Prairie Crown supports their workers. #SupportRestaurants
    - We're matching every donation to the #ServeThemStrong fund to help restaurant workers through COVID closures. Donate at the link in bio.
    - Our favorite local restaurant: This month a portion of every pint sold at Milwaukee restaurants goes to the restaurant workers' fund. Tip your bartender.
    - Our favorite local restaurant: We donated $50,000 to the Austin restaurant workers' fund to help bartenders and servers. Tip your bartender.
    - Support local restaurants. Restaurants and bars: tell us you're open for takeout and we'll help support your workers. #SupportRestaurants
    - Update on the #ServeThemStrong fund: Donate to the #ServeThemStrong relief fund and help restaurant workers pay rent this month. Donate at the link in bio.
    - Supporting restaurant workers. This month a portion of every pint sold at Portland restaurants goes to the restaurant workers' fund.
    - Order takeout tonight. Tag a local restaurant still serving curbside and we'll donate $5 to help its workers.
    - Brewers across the country have joined the #ServeThemStrong fund to support restaurant workers. Donate today. Thank you for helping restaurant workers.
    - We miss bars too. Help keep your neighborhood restaurant open: order takeout and support the workers behind it. #OpenForTakeout
    - Order takeout from your favorite restaurant and we'll donate to the restaurant worker relief fund. #SupportRestaurants
    - Update on the #ServeThemStrong fund: Every donation to the #ServeThemStrong relief fund goes straight to out-of-work restaurant workers. Thank you for helping restaurant workers.
    - Supporting restaurant workers. Visit our partner restaurants in Austin this week; a dollar from every a Copper Hollow old fashioned supports their workers. Tip your bartender.
    - Help keep your neighborhood restaurant open: order takeout and support the workers behind it. #OpenForTakeout
    - Support local restaurants. Tag a local restaurant still serving curbside and we'll donate $5 to help its workers.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 8: "Sunny Escapes: Beach Vibes & Drink Orders"
- Modal vote share: 45.0% (9/20); margin over runner-up: 35.0%
- Representative words: sunshine, alittlesunshine, bit, sunnier, beach, little, order, sunny, get, way
- Sampled documents (n=15):
    - Need a little sunshine? Order Coral Cove for delivery and add a bit of sunshine to your day. #ALittleSunshine Order through Pourly. @CoralCoveRum
    - Need a little sunshine? Happy hour at home just got sunnier. Order Coral Cove Rum and share your view. #ALittleSunshine
    - Island time, living room edition. Happy hour at home just got sunnier. Order Coral Cove and share your view. #ALittleSunshine Stay sunny.
    - Brighter days are on the way. Get a Coral Cove and pineapple delivered and make today a little sunnier. Code POURLY5 for $5 off. #StaySunny
    - Need a little sunshine? Get Coral Cove Rum delivered and make today a little sunnier. Code BRIGHT5 for $5 off.
    - Your daily dose of sunshine: Coral Cove, ice, and a beach playlist. #ALittleSunshine
    - Order Coral Cove for delivery and add a bit of sunshine to your day. #ALittleSunshine
    - Sending a bit of sunshine your way. A bit of sunshine, delivered to your door in under an hour. #ALittleSunshine Stay sunny. @MaretaRum
    - A bit of sunshine, delivered to your door in under an hour. #ALittleSunshine Stay sunny.
    - Bring the beach inside. Happy hour at home just got sunnier. Order a Coral Cove and pineapple and share your view. #ALittleSunshine
    - Get a Mareta mojito delivered and make today a little sunnier. Code SIPHOME for $5 off. Stay sunny.
    - Bring the beach inside. Share a bit of sunshine: tell us the happiest part of your day. #ALittleSunshine Stay sunny.
    - Your daily dose of sunshine: a Coral Cove and pineapple, ice, and a beach playlist. #ALittleSunshine Stay sunny.
    - Sending a bit of sunshine your way. A bit of sunshine, delivered to your door in under an hour. #ALittleSunshine #StaySunny
    - Happy hour at home just got sunnier. Order a Coral Cove and pineapple and share your view. #ALittleSunshine Order through Pourly.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 9: "Virtual Home Sports Challenges"
- Modal vote share: 35.0% (7/20); margin over runner-up: 0.0%
- Representative words: couchleague, video, challenge, submit, put, home, team, skill, sport, best
- Sampled documents (n=15):
    - Home team, assemble. Show us your backyard putting setup. Best #CouchLeague video wins a custom putting mat. Tag a teammate.
    - Week two of the #CouchLeague home sports challenge is open. Submit your video by Friday.
    - Home team, assemble. Week two of the #CouchLeague home sports challenge is open. Submit your video by Friday. Tag a teammate.
    - Think you've got skills? Submit your best at-home trick shot video with #CouchLeague for a chance to win a team prize. #CouchLeague
    - Challenge accepted. Submit your best at-home trick shot video with #CouchLeague for a chance to win a team prize. #CouchLeague
    - Home team, assemble. Show us your backyard putting setup. Best #CouchLeague video wins a custom putting mat.
    - The #CouchLeague is here. Pro athletes picked their #CouchLeague teams. Submit your home workout video to join one. #CouchLeague @LanternlightBeer
    - Home team, assemble. Laundry basket hoops, hallway hockey, kitchen soccer: post your #CouchLeague challenge video. #CouchLeague
    - Think you've got skills? Submit your best at-home trick shot video with #CouchLeague for a chance to win a team prize. Tag a teammate.
    - Sports are on hold. Your skills aren't. The #CouchLeague challenge: ten books, three notebooks and a foam roller. Stick the landing.
    - The #CouchLeague is here. Submit your best at-home trick shot video with #CouchLeague for a chance to win a team prize. Rules in bio. 21+.
    - Think you've got skills? Pro athletes picked their #CouchLeague teams. Submit your home workout video to join one. Rules in bio. 21+.
    - Challenge accepted. Pro athletes picked their #CouchLeague teams. Submit your home workout video to join one. Tag a teammate.
    - Home team, assemble. Submit your best at-home trick shot video with #CouchLeague for a chance to win a team prize. @BrightwaterSeltzer
    - Home team, assemble. Pro athletes picked their #CouchLeague teams. Submit your home workout video to join one. Tag a teammate.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 10: "Classic Cocktail Creations"
- Modal vote share: 55.0% (11/20); margin over runner-up: 45.0%
- Representative words: oz, shaken, juice, lemon, ice, sour, syrup, hard, egg, fizz
- Sampled documents (n=15):
    - Taste test complete. Try the Hollowmere Fizz: 1.5 oz herbal liqueur, lemon, egg white and soda, dry shaken then shaken again. Back soon with more.
    - Weekend project, the Copper Sunrise: 1.5 oz whiskey, orange juice, a splash of grenadine, poured slowly over ice. Back soon with more.
    - Straight from the tasting room. Try the Old Sour: 2 oz pale ale, 3/4 oz lemon juice, 1/2 oz simple syrup, shaken hard with ice.
    - Recipe of the week, the Copper Sour: 2 oz whiskey, 3/4 oz lemon juice, 1/2 oz simple syrup, shaken hard with ice. As always, cheers.
    - Try the Kingsgate Sour: 2 oz pale ale, 3/4 oz lemon juice, 1/2 oz simple syrup, shaken hard with ice. As always, cheers.
    - Make the Kingsgate Sunrise at home: 1.5 oz pale ale, orange juice, a splash of grenadine, poured slowly over ice. Back soon with more.
    - Taste test complete. Weekend project, the Lanternlight Fizz: 1.5 oz lager, lemon, egg white and soda, dry shaken then shaken again.
    - Bartender's pick, the Kingsgate Sunrise: 1.5 oz pale ale, orange juice, a splash of grenadine, poured slowly over ice. #KingsgateMoments
    - Straight from the tasting room. Try the Hollowmere Sour: 2 oz herbal liqueur, 3/4 oz lemon juice, 1/2 oz simple syrup, shaken hard with ice. Cheers from Phoenix.
    - Make the Old Sour at home: 2 oz pale ale, 3/4 oz lemon juice, 1/2 oz simple syrup, shaken hard with ice.
    - Just saying. Make the Old Sour at home: 2 oz pale ale, 3/4 oz lemon juice, 1/2 oz simple syrup, shaken hard with ice. 21+ only, please.
    - Taste test complete. Recipe of the week, the Kingsgate Sunrise: 1.5 oz pale ale, orange juice, a splash of grenadine, poured slowly over ice. 21+ only, please.
    - Recipe of the week, the Lanternlight Sour: 2 oz lager, 3/4 oz lemon juice, 1/2 oz simple syrup, shaken hard with ice.
    - Make the Coral Fizz at home: 1.5 oz rum, lemon, egg white and soda, dry shaken then shaken again.
    - Make the Old Sour at home: 2 oz pale ale, 3/4 oz lemon juice, 1/2 oz simple syrup, shaken hard with ice. Cheers from Boston.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 11: "Esports Charity Streaming Events During COVID-19"
- Modal vote share: 45.0% (9/20); margin over runner-up: 30.0%
- Representative words: twitch, charity, royale, game, stream, gg, money, esports, watch, final
- Sampled documents (n=15):
    - Controllers ready? New partnership: Copper Hollow Whiskey is teaming up with DeepCutDev for a monthly gaming stream. #GameNight
    - Stream starts soon. New partnership: Hollowmere Herbal Liqueur is teaming up with SlateRunner for a monthly gaming stream. GG everyone.
    - Finals tonight! The Charity Royale finals stream tonight at 7pm CT on our Twitch channel. All money goes to charity. Tune in.
    - Finals tonight! Twenty-four pro athletes battle in the Charity Royale on Twitch to raise money for local causes. Gaming for good.
    - Controllers ready? Join our community game night on Twitch tonight. Winners get Brightwater Hard Seltzer gear.
    - Esports fans: Our gaming stream is live at 6pm PT: Lunewave plays with fans for prizes.
    - Join our community game night on Twitch this weekend. Winners get Coral Cove Rum gear.
    - Controllers ready? Our gaming stream is live at 8pm ET: DeepCutDev plays with fans for prizes.
    - Esports fans: The esports finals are on and a Brightwater is the official drink of the watch party (21+). GG everyone.
    - Esports fans: New partnership: Coral Cove Rum is teaming up with NorthByNorth for a monthly gaming stream.
    - Esports fans: Our gaming stream is live at 9pm EST: Pixel_Ox plays with fans for prizes.
    - Live right now on Twitch! Every Charity Royale win sends money to local food banks. Tune in on Twitch at 6pm EST. #CharityRoyale
    - Controllers ready? New partnership: Lanternlight Lager is teaming up with DeepCutDev for a monthly gaming stream. Link in bio.
    - Game night. New partnership: Hollowmere Herbal Liqueur is teaming up with kilnfire for a monthly gaming stream. GG everyone. @Hollowmere
    - Game night. Proud to sponsor the Nashville esports team at this weekend's tournament. Watch on Twitch. Link in bio.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 12: "Pandemic Social Media Giveaway Campaigns"
- Modal vote share: 20.0% (4/20); margin over runner-up: 5.0%
- Representative words: chance, retweet, merch, win, howdyneighbor, follow, new, tag, crewneck, collection
- Sampled documents (n=15):
    - Tag your crew. Retweet and follow for a chance to win fresh #HowdyNeighbor merch for your whole crew. Rules in bio. 21+.
    - Who would you share one with right now? Retweet and follow for a chance to win fresh #HowdyNeighbor merch for your whole crew.
    - Tag a friend you miss and say #HowdyNeighbor for a chance to win our new crewneck. Winners announced Friday. @TidepoolSeltzer
    - Tag your crew. Tag a friend you miss and say #HowdyNeighbor for a chance to win our new crewneck. @PrairieCrown
    - Win it before it's gone. Tag a friend you miss and say #HowdyNeighbor for a chance to win our new crewneck. Winners announced Friday. @PrairieCrown
    - Win it before it's gone. Our new merch collection drops this week. Follow and retweet for a chance to win it first.
    - Who would you share one with right now? Retweet and follow for a chance to win fresh #HowdyNeighbor merch for your whole crew. Winners announced Friday.
    - Retweet and follow for a chance to win fresh #HowdyNeighbor merch for your whole crew. Winners announced Friday.
    - Giveaway time! Retweet and follow for a chance to win fresh #HowdyNeighbor merch for your whole crew.
    - Retweet and follow for a chance to win fresh #HowdyNeighbor merch for your whole crew.
    - Giveaway time! Tag a friend you miss and say #HowdyNeighbor for a chance to win our new crewneck. Good luck!
    - Who would you share one with right now? Tag a friend you miss and say #HowdyNeighbor for a chance to win our new crewneck. Winners announced Friday.
    - New merch alert. Retweet and follow for a chance to win fresh #HowdyNeighbor merch for your whole crew. Rules in bio. 21+.
    - Who would you share one with right now? Retweet and follow for a chance to win fresh #HowdyNeighbor merch for your whole crew. Rules in bio. 21+.
    - Giveaway time! Tag a friend you miss and say #HowdyNeighbor for a chance to win our new crewneck. Rules in bio. 21+.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 13: "Breweries' Creative Adaptations During COVID-19"
- Modal vote share: 15.0% (3/20); margin over runner-up: 0.0%
- Representative words: paint, mural, dock, load, head, brewer, crew, room, shift, taste
- Sampled documents (n=15):
    - From our Kansas City taproom: Our head brewer painted a mural on the loading dock. Made with care in Kansas City.
    - Quick reminder: The night shift painted a mural on the loading dock.
    - From our Denver taproom: Our founder painted a mural on the loading dock. As always, cheers.
    - Taste test complete. The night shift painted a mural on the loading dock. #OldMoments
    - Quick reminder: The night shift painted a mural on the loading dock. #KingsgateCheers
    - Simple pleasures. Our head brewer painted a mural on the loading dock. Back soon with more.
    - Taste test complete. Our founder painted a mural on the loading dock. Made with care in Boston.
    - From our Boston taproom: Our master blender painted a mural on the loading dock. Cheers.
    - The packaging line painted a mural on the loading dock.
    - Taste test complete. The packaging line painted a mural on the loading dock. Back soon with more.
    - Straight from the tasting room. The night shift painted a mural on the loading dock.
    - Small joys. The bottling crew painted a mural on the loading dock. Pour accordingly.
    - Our founder painted a mural on the loading dock. Raise a glass.
    - From our Phoenix taproom: The night shift painted a mural on the loading dock. Back soon with more.
    - Fun fact: Our master blender painted a mural on the loading dock. Cheers.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 14: "Virtual Home Bar Experiences"
- Modal vote share: 90.0% (18/20); margin over runner-up: 85.0%
- Representative words: ig, livingroomtour, bar, live, dive, real, living, tune, virtual, bring
- Sampled documents (n=15):
    - We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 7pm ET.
    - We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 8pm ET. See you there.
    - Don't miss it. Live music, virtual bar, real drinks. Tune in to the #LivingRoomTour on IG tomorrow night.
    - We're live in five. Live music, virtual bar, real drinks. Tune in to the #LivingRoomTour on IG Thursday. See you there.
    - Your living room, our stage. We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 9pm EST. Link in bio.
    - Your living room, our stage. Live music, virtual bar, real drinks. Tune in to the #LivingRoomTour on IG tonight.
    - We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 6pm EST. See you there. @LanternlightBeer
    - Don't miss it. We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 7pm CT. See you there.
    - Tune in tonight. We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 6pm PT. Set your reminder.
    - We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 8pm CT. See you there.
    - Live music, virtual bar, real drinks. Tune in to the #LivingRoomTour on IG this Friday.
    - Live music, virtual bar, real drinks. Tune in to the #LivingRoomTour on IG Saturday night. Link in bio.
    - We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 7pm CT.
    - Don't miss it. We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 6pm EST.
    - We're bringing the dive bar to your living room. #LivingRoomTour live on IG at 9pm EST. Set your reminder. @LanternlightBeer

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 15: "Pandemic Brewing: Industry Adaptations and Community Engagement"
- Modal vote share: 15.0% (3/20); margin over runner-up: 5.0%
- Representative words: rye, talk, stop, test, shift, crew, farm, head, brewer, night
- Sampled documents (n=15):
    - For the record: The bottling crew is testing a rye we can't stop talking about. #LanternlightTime #Cheers
    - Noted. Our quality lab is testing a rye we can't stop talking about.
    - Our founder is testing a rye we can't stop talking about. Made with care in Atlanta.
    - Simple pleasures. Our founder is testing a rye we can't stop talking about.
    - The night shift is testing a rye we can't stop talking about.
    - Our head brewer is testing a rye we can't stop talking about.
    - The night shift is testing a rye we can't stop talking about. Pour accordingly.
    - On the menu today: The barrel room is testing a rye we can't stop talking about. #CopperLife
    - For the record: The cellar team is testing a rye we can't stop talking about. Enjoy responsibly.
    - Taste test complete. Our head brewer is testing a rye we can't stop talking about. Enjoy responsibly.
    - Noted. The packaging line is testing a rye we can't stop talking about.
    - From our Milwaukee taproom: The farm crew is testing a rye we can't stop talking about. Pour accordingly.
    - Simple pleasures. Our distillery cat is testing a rye we can't stop talking about. Cheers from San Diego.
    - Noted. The packaging line is testing a rye we can't stop talking about. Cheers.
    - The farm crew is testing a rye we can't stop talking about. Enjoy responsibly.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 16: "Cinnamon Hot Toddy Recipe Promotion"
- Modal vote share: 20.0% (4/20); margin over runner-up: 10.0%
- Representative words: cinnamon, toddy, hot, stick, honey, lemon, water, oz, project, pale
- Sampled documents (n=15):
    - Noted. Bartender's pick, the Coral Toddy: 1.5 oz rum, hot water, honey, lemon and a cinnamon stick. Made with care in Boston.
    - Taste test complete. Bartender's pick, the Hollowmere Toddy: 1.5 oz herbal liqueur, hot water, honey, lemon and a cinnamon stick. Enjoy responsibly.
    - Try the Old Toddy: 1.5 oz pale ale, hot water, honey, lemon and a cinnamon stick. 21+ only, please.
    - Weekend project, the Brightwater Toddy: 1.5 oz hard seltzer, hot water, honey, lemon and a cinnamon stick. #BrightwaterMoments
    - Weekend project, the Hollowmere Toddy: 1.5 oz herbal liqueur, hot water, honey, lemon and a cinnamon stick. Pour accordingly.
    - Bartender's pick, the Lanternlight Toddy: 1.5 oz lager, hot water, honey, lemon and a cinnamon stick.
    - Weekend project, the Brightwater Toddy: 1.5 oz hard seltzer, hot water, honey, lemon and a cinnamon stick. #BrightwaterLife #Cheers
    - Weekend project, the Lanternlight Toddy: 1.5 oz lager, hot water, honey, lemon and a cinnamon stick. #LanternlightLife #Cheers
    - Recipe of the week, the Lanternlight Toddy: 1.5 oz lager, hot water, honey, lemon and a cinnamon stick.
    - Bartender's pick, the Coral Toddy: 1.5 oz rum, hot water, honey, lemon and a cinnamon stick. Back soon with more.
    - Weekend project, the Coral Toddy: 1.5 oz rum, hot water, honey, lemon and a cinnamon stick.
    - Weekend project, the Old Toddy: 1.5 oz pale ale, hot water, honey, lemon and a cinnamon stick. Made with care in Austin.
    - Bartender's pick, the Hollowmere Toddy: 1.5 oz herbal liqueur, hot water, honey, lemon and a cinnamon stick.
    - Try the Old Toddy: 1.5 oz pale ale, hot water, honey, lemon and a cinnamon stick. Back soon with more.
    - Taste test complete. Try the Old Toddy: 1.5 oz pale ale, hot water, honey, lemon and a cinnamon stick.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 17: "Tropical Cocktail Innovations"
- Modal vote share: 40.0% (8/20); margin over runner-up: 25.0%
- Representative words: part, colada, smooth, cream, blend, coconut, pineapple, try, pale, project
- Sampled documents (n=15):
    - Try the Coral Colada: 2 parts rum, 3 parts pineapple, 1 part coconut cream, blended until smooth. Cheers from Boston.
    - Weekend project, the Brightwater Colada: 2 parts hard seltzer, 3 parts pineapple, 1 part coconut cream, blended until smooth. Made with care in Portland.
    - Noted. Weekend project, the Copper Colada: 2 parts whiskey, 3 parts pineapple, 1 part coconut cream, blended until smooth. #CopperMoments
    - Weekend project, the Copper Colada: 2 parts whiskey, 3 parts pineapple, 1 part coconut cream, blended until smooth.
    - Make the Mareta Colada at home: 2 parts rum, 3 parts pineapple, 1 part coconut cream, blended until smooth. Raise a glass.
    - Try the Prairie Colada: 2 parts lager, 3 parts pineapple, 1 part coconut cream, blended until smooth. Back soon with more.
    - Noted. Try the Kingsgate Colada: 2 parts pale ale, 3 parts pineapple, 1 part coconut cream, blended until smooth. Raise a glass.
    - Simple pleasures. Try the Mareta Colada: 2 parts rum, 3 parts pineapple, 1 part coconut cream, blended until smooth. Made with care in Charlotte.
    - Recipe of the week, the Prairie Colada: 2 parts lager, 3 parts pineapple, 1 part coconut cream, blended until smooth. Cheers.
    - Weekend project, the Lanternlight Colada: 2 parts lager, 3 parts pineapple, 1 part coconut cream, blended until smooth. #LanternlightCheers #Cheers
    - Noted. Try the Old Colada: 2 parts pale ale, 3 parts pineapple, 1 part coconut cream, blended until smooth. #OldTime #Cheers
    - Try the Copper Colada: 2 parts whiskey, 3 parts pineapple, 1 part coconut cream, blended until smooth.
    - Recipe of the week, the Hollowmere Colada: 2 parts herbal liqueur, 3 parts pineapple, 1 part coconut cream, blended until smooth. Pour accordingly.
    - Noted. Make the Kingsgate Colada at home: 2 parts pale ale, 3 parts pineapple, 1 part coconut cream, blended until smooth. Raise a glass.
    - Just saying. Try the Old Colada: 2 parts pale ale, 3 parts pineapple, 1 part coconut cream, blended until smooth.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 18: "Refreshing Cocktail Innovations"
- Modal vote share: 30.0% (6/20); margin over runner-up: 15.0%
- Representative words: highball, topped, twist, sparkle, long, lemon, water, oz, project, pick
- Sampled documents (n=15):
    - Weekend project, the Frostline Highball: 1.5 oz vodka topped with sparkling water and a long lemon twist. Enjoy responsibly.
    - Bartender's pick, the Hollowmere Highball: 1.5 oz herbal liqueur topped with sparkling water and a long lemon twist.
    - Weekend project, the Kingsgate Highball: 1.5 oz pale ale topped with sparkling water and a long lemon twist. As always, cheers.
    - Weekend project, the Lanternlight Highball: 1.5 oz lager topped with sparkling water and a long lemon twist. As always, cheers.
    - Weekend project, the Old Highball: 1.5 oz pale ale topped with sparkling water and a long lemon twist.
    - Small joys. Try the Copper Highball: 1.5 oz whiskey topped with sparkling water and a long lemon twist. Raise a glass.
    - Simple pleasures. Try the Copper Highball: 1.5 oz whiskey topped with sparkling water and a long lemon twist. #CopperMoments
    - Small joys. Bartender's pick, the Brightwater Highball: 1.5 oz hard seltzer topped with sparkling water and a long lemon twist. As always, cheers.
    - Make the Mareta Highball at home: 1.5 oz rum topped with sparkling water and a long lemon twist. Raise a glass.
    - Noted. Weekend project, the Copper Highball: 1.5 oz whiskey topped with sparkling water and a long lemon twist. Raise a glass.
    - Weekend project, the Kingsgate Highball: 1.5 oz pale ale topped with sparkling water and a long lemon twist. Pour accordingly.
    - Recipe of the week, the Old Highball: 1.5 oz pale ale topped with sparkling water and a long lemon twist.
    - Simple pleasures. Make the Old Highball at home: 1.5 oz pale ale topped with sparkling water and a long lemon twist. As always, cheers.
    - Weekend project, the Old Highball: 1.5 oz pale ale topped with sparkling water and a long lemon twist. #OldMoments
    - Recipe of the week, the Hollowmere Highball: 1.5 oz herbal liqueur topped with sparkling water and a long lemon twist. Made with care in Omaha.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 19: "Pandemic Engagement and Promotions"
- Modal vote share: 70.0% (14/20); margin over runner-up: 55.0%
- Representative words: could, merch, reply, share, friend, year, win, alert, would, right
- Sampled documents (n=15):
    - New merch alert. Reply with the friend you'd share a Brightwater with and you could win a year of merch. Rules in bio. 21+.
    - Who would you share one with right now? Reply with the friend you'd share a can of Brightwater with and you could win a year of merch. Winners announced Friday.
    - Tag your crew. Reply with the friend you'd share Prairie Crown with and you could win a year of merch.
    - Win it before it's gone. Reply with the friend you'd share Brightwater with and you could win a year of merch.
    - Tag your crew. Reply with the friend you'd share a cold Prairie Crown with and you could win a year of merch. Winners announced Friday.
    - Giveaway time! Reply with the friend you'd share a Prairie Crown with and you could win a year of merch.
    - Tag your crew. Reply with the friend you'd share a Prairie Crown with and you could win a year of merch. Rules in bio. 21+.
    - Reply with the friend you'd share Prairie Crown with and you could win a year of merch. Rules in bio. 21+.
    - Reply with the friend you'd share Brightwater with and you could win a year of merch. Good luck!
    - Win it before it's gone. Reply with the friend you'd share a Tidepool with and you could win a year of merch. Good luck!
    - New merch alert. Reply with the friend you'd share Prairie Crown with and you could win a year of merch.
    - Who would you share one with right now? Reply with the friend you'd share Brightwater with and you could win a year of merch. Winners announced Friday.
    - Reply with the friend you'd share a Prairie Crown with and you could win a year of merch.
    - Win it before it's gone. Reply with the friend you'd share a Prairie Crown with and you could win a year of merch. Good luck!
    - Giveaway time! Reply with the friend you'd share a can of Brightwater with and you could win a year of merch. Winners announced Friday.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 

## Topic 20: Tropical Cocktail Innovations During COVID-19
- Modal vote share: 50.0% (10/20); margin over runner-up: 25.0%
- Representative words: bitter, dash, crowd, punch, coconut, juice, water, pineapple, batch, try
- Sampled documents (n=15):
    - Try the Lanternlight Punch: lager, pineapple juice, coconut water and a dash of bitters, batched for a crowd. #LanternlightTime #Cheers
    - Small joys. Recipe of the week, the Copper Punch: whiskey, pineapple juice, coconut water and a dash of bitters, batched for a crowd. Back soon with more.
    - Try the Old Punch: pale ale, pineapple juice, coconut water and a dash of bitters, batched for a crowd.
    - Noted. Try the Lanternlight Punch: lager, pineapple juice, coconut water and a dash of bitters, batched for a crowd. Raise a glass.
    - Weekend project, the Coral Punch: rum, pineapple juice, coconut water and a dash of bitters, batched for a crowd. Cheers.
    - Recipe of the week, the Hollowmere Punch: herbal liqueur, pineapple juice, coconut water and a dash of bitters, batched for a crowd.
    - Recipe of the week, the Hollowmere Punch: herbal liqueur, pineapple juice, coconut water and a dash of bitters, batched for a crowd. Enjoy responsibly.
    - Bartender's pick, the Copper Punch: whiskey, pineapple juice, coconut water and a dash of bitters, batched for a crowd. Cheers.
    - Simple pleasures. Weekend project, the Old Punch: pale ale, pineapple juice, coconut water and a dash of bitters, batched for a crowd. Pour accordingly.
    - Simple pleasures. Weekend project, the Coral Punch: rum, pineapple juice, coconut water and a dash of bitters, batched for a crowd. Cheers from Kansas City.
    - Bartender's pick, the Prairie Punch: lager, pineapple juice, coconut water and a dash of bitters, batched for a crowd. #PrairieCheers #Cheers
    - Taste test complete. Bartender's pick, the Brightwater Punch: hard seltzer, pineapple juice, coconut water and a dash of bitters, batched for a crowd. Cheers.
    - Try the Prairie Punch: lager, pineapple juice, coconut water and a dash of bitters, batched for a crowd.
    - Noted. Try the Coral Punch: rum, pineapple juice, coconut water and a dash of bitters, batched for a crowd. #CoralCheers
    - Small joys. Weekend project, the Coral Punch: rum, pineapple juice, coconut water and a dash of bitters, batched for a crowd. Pour accordingly.

**Primary researcher notes:** 
**Senior researcher critique:** 
**Consensus candidate theme:** 
